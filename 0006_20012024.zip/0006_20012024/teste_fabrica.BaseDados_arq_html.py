from armazem import CriadorArqConteudo
from armazem import CriadorArqHtml
from fabrica import FabArqHtml
"""_
    Teste do pattern Factory com duas formas diferentes de instaciaçãp
"""
#forma 01
arqC = CriadorArqConteudo()
arqC.setIdentificador('111')
arqC.setConteudo('teste fabrica conteudo')

arqH = CriadorArqHtml()
arqH.setIdentificador('222')
arqH.setConteudo('teste frabrica html')


cont=0
for x in [arqC,arqH]:
    fab = FabArqHtml.criar(obj=x)
    fab.executarArmazenamento()
    print(fab)
    
    
#forma 02
cont=0
for x in [CriadorArqConteudo,CriadorArqHtml]:
    fab = FabArqHtml.criar(obj=x,identificador='bdf'+str(cont),conteudo='123'+str(cont))
    fab.executarArmazenamento()
    print(fab)
    cont+=1

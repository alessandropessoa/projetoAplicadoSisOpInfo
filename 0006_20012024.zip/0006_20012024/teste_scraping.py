from webScraping import Scraping 
from webScraping import ExtratorParagrafo
from webScraping import Requisicao

url="https://www.santaportal.com.br/ultimas-noticias/16h-entenda-como-vai-funcionar-a-glo-nos-portos-e-aeroportos-de-sp-e-do-rj"
url2="https://erro123.com"

sc = Scraping()
sc.setUrlRaspagem(url)
sc.setReq(Requisicao)
sc.setExt(ExtratorParagrafo)
sc.raspar()
print(sc.getConteudo())


sc.setUrlRaspagem(url2)
sc.raspar()
print(sc.getConteudo())

# from gerenciadorBancoDeDados import GerenciadorDB
# from fabrica import FabArqHtml

# operacao = FabArqHtml()
# op = operacao.criar()


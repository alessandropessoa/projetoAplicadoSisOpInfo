from webScraping import GerenciadorSC, Scraping, Requisicao, ExtratorParagrafo

url ="https://f5.folha.uol.com.br/televisao/2024/01/elas-por-elas-internamente-globo-admite-que-errou-com-horario-de-remake-da-novela.shtml"

sc = Scraping(url=url, req=Requisicao, ext=ExtratorParagrafo)
ger= GerenciadorSC(repositorio=sc)
res = ger.executarRaspagem()

print("status raspagem: ",res)

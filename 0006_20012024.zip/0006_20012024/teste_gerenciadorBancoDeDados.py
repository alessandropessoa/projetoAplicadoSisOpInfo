from gerenciadorBancoDeDados import GerenciadorDB
from armazem import CriadorArqHtml
from armazem import CriadorArqConteudo

t1 = CriadorArqConteudo()
t1.setIdentificador("1333")
t1.setConteudo('sdjlgkjrk')
t1.armazenar()

t2 = CriadorArqHtml()
t2.setIdentificador("22223")
t2.setConteudo('aaaaa')
t2.armazenar()

colecao = [t1,t2]
inst =[GerenciadorDB(x) for x in colecao]

for x in inst:
    x.executarArmazenamento()

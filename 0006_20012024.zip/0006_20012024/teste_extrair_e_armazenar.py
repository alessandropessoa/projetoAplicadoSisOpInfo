
from webScraping import ExtratorParagrafo, Requisicao
from armazem import CriadorArqConteudo
from armazem import CriadorArqHtml
from fabrica import FabArqHtml
from fabrica import FabScrap
import pandas as pd
from decouple import config
import os

path= os.getcwd()+config('path_db_csv')
dataSet = pd.read_csv(f"{path}baseDados.csv")

arqC = CriadorArqConteudo()
arqH = CriadorArqHtml()

for x in dataSet['url']:
    print(x)
    t =  FabScrap.criar(objReq=Requisicao, objExt=ExtratorParagrafo, url=x)
    t.raspar()
    data = dataSet[dataSet['url']==x]
    ident =f"{str(data.identificador.to_list()[0])}_{data.polaridade_texto.to_list()[0]}"

    arqC.setIdentificador(ident)
    arqC.setConteudo(" \n".join(t.getConteudo()))
    
    arqH.setIdentificador(ident) 
    arqH.setConteudo("".join(t.pagHtml))
    
    fab = FabArqHtml.criar(obj=arqC)
    fab.executarArmazenamento()
    
    fab2 = FabArqHtml.criar(obj=arqH)
    fab2.executarArmazenamento()
  
    


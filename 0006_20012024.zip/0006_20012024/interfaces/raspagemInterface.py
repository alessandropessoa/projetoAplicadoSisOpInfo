from abc import ABC,abstractmethod

class RaspagemInterface(ABC):
    @abstractmethod
    def setUrlRaspagem(self,url:str):
        raise NotImplemented
        self._url=url
        
    @abstractmethod
    def getUrlRaspagem(self)->str:
        raise NotImplemented
        return self._url
    
    @abstractmethod
    def getConteudo(self):
        raise NotImplemented
    
    @abstractmethod
    def raspar(self):
        raise NotImplemented
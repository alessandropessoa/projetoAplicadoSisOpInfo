from .requisicao import Requisicao
from .extratorParagrafoWeb import ExtratorParagrafo
from .scraping import Scraping
from .gerenciadorScraping import GerenciadorSC
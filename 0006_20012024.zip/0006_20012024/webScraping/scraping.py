from interfaces import RaspagemInterface
from typing import Type
from webScraping import  ExtratorParagrafo, Requisicao
from log import Log

class Scraping(RaspagemInterface):
    def __init__(self,url,req=Requisicao, ext=ExtratorParagrafo):
        self._url = url
        self._conteudo =""
        self._req = req
        self._ext = ext
        self._log = Log()
        self.pagHtml = ""
        
    def setUrlRaspagem(self,url:str):
        self._url = url
           
    def getUrlRaspagem(self)->str:
        return self._url
    
    def getConteudo(self)->str:
        return self._conteudo
    
    def _processoRaspagem(self,req, ext):
        req = req
        req.copiar(url=self._url)
        statusReq =req.getStatusRequisicao()
        
        if statusReq==0:
            self._log.criarEvento(f'Status requisição http: {statusReq} | Essa url não existe ou esta você esta sem rede. | {req.getUrl()}')
        
        elif statusReq>=200 and statusReq<=200 :
            print("valorrr  de status", statusReq)
            paginaweb =req.paginaWebTratada()  
            self.pagHtml = req.pagHtml
            ext = ext
            self._conteudo = ext.getConteudo(paginaWeb=paginaweb)
            self._log.criarEvento(f'Status requisição http: {statusReq} | (200) bem sucedida ou (100)informação | {req.getUrl()}')
            return "sucesso"
            
        elif  statusReq >=400 and statusReq <=400:    
            self._log.criarEvento(f'Status requisição http: {statusReq} | erro do cliente | {req.getUrl()}')
            return "pagina não encontrada"
            
        elif statusReq >=500 and statusReq <=599:    
            self._log.criarEvento(f'Status requisição http: {statusReq} | erro do servidor | {req.getUrl()}')
            return "erro interno do servidor"
        else:
            return "Falha raspagem"
        
    def setReq(self,req:Type[Requisicao]):
        self._req = req
        
    def setExt(self,ext:Type[ExtratorParagrafo]):
        self._ext = ext
        
    def raspar(self):
        self.setUrlRaspagem(self._url)
        return self._processoRaspagem(self._req, self._ext)



        
    

from webScraping import ExtratorParagrafo
from webScraping import Requisicao

url='https://www.santaportal.com.br/ultimas-noticias/16h-entenda-como-vai-funcionar-a-glo-nos-portos-e-aeroportos-de-sp-e-do-rj'

req = Requisicao()
req.copiar(url=url)

assert req.getStatusRequisicao() == 200
paginaWeb = req.paginaWebTratada()

ext = ExtratorParagrafo()
conteudo =ext.getConteudo(paginaWeb=paginaWeb)

print(conteudo)
from log import Log
import time
lg = Log()

lg.criarEvento('evento 001')
time.sleep(2)
lg.criarEvento('evento 002')
from armazem import CriadorArqConteudo

t1 = CriadorArqConteudo()
t1.setIdentificador("132")
t1.setConteudo('sdjlgkjrk')
t1.armazenar()
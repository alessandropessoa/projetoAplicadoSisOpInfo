from armazem import CriadorArqHtml

t1 = CriadorArqHtml()
t1.setIdentificador("444")
t1.setConteudo('sdjlgkjrk')
t1.armazenar()
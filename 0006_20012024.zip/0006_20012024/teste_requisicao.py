from webScraping import Requisicao

url='https://www.santaportal.com.br/ultimas-noticias/16h-entenda-como-vai-funcionar-a-glo-nos-portos-e-aeroportos-de-sp-e-do-rj'

req = Requisicao()
req.copiar(url=url)

assert req.getStatusRequisicao() == 200
print(req.paginaWebTratada())
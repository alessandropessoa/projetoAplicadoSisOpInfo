from gerenciadorBancoDeDados import GerenciadorDB
from interfaces import ArmazenadorInterface
from typing import Type

class FabArqHtml():
    @staticmethod
    def criar(obj:Type[ArmazenadorInterface],identificador='',conteudo='')-> GerenciadorDB:
        if (identificador !="") and (conteudo != "" ):
            obj = obj()
            obj.setIdentificador(identificador=identificador)
            obj.setConteudo(conteudo=conteudo)
        else:
            obj = obj
        return GerenciadorDB(obj)
    
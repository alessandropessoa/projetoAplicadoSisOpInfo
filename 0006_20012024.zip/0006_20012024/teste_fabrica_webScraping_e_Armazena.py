from fabrica import FabScrap
from webScraping import  Requisicao, ExtratorParagrafo


url="https://agenciabrasil.ebc.com.br/geral/noticia/2023-11/saiba-como-vai-funcionar-glo-nos-portos-e-aeroportos-do-rj-e-de-sp#:~:text=A%20Carta%20Magna%20estabeleceu%2C%20em,Executivo%2C%20Legislativo%20e%20Judici%C3%A1rio)."
t =  FabScrap.criar(objReq=Requisicao, objExt=ExtratorParagrafo, url=url)
t.raspar()
t.getConteudo()
print(t.getConteudo())
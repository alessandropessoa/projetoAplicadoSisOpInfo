from typing import Dict
from interfaces import ArmazenadorInterface
import os
from decouple import config

class CriadorArqHtml(ArmazenadorInterface):
    def __init__(self):
        self._identificador = self.setIdentificador()
        self._conteudo      = self.setConteudo()
        
    def setIdentificador(self,identificador=""):
        self._identificador = identificador

    def getIdentificador(self)-> str:
        return self._identificador

    def setConteudo(self,conteudo=""):
        self._conteudo = conteudo
        
    def getConteudo(self)->str:
        return self._conteudo
        
    def armazenar(self)-> Dict:
        status ={'status':None,'erro':None}
        
        nome = f'{self._identificador}.html'
        caminho = os.getcwd()+config('path_db_html')
        try:
            with open(f"{caminho}{nome}",'a') as arq:
                arq.write(self._conteudo)
                status['status']='sucesso'
                
        except Exception as error:
            status['status'] = f"{error}"
            
        finally:    
            return status
from typing import Type,Union,Dict
from interfaces import ArmazenadorInterface

class GerenciadorDB():
    def __init__(self, repositorio:Type[ArmazenadorInterface]):
        self.__obj = repositorio
    
    def executarArmazenamento(self)->Union[Dict,None]:
        if self.__obj.getIdentificador() != "" and self.__obj.getConteudo():
            _status= self.__obj.armazenar()
            return _status
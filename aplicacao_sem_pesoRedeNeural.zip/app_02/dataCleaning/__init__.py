from .tiposLimpeza import  RemoveNumeros,\
                            RemovePontuacao,\
                            RemoveEspaco,\
                            RemoveEmail,\
                            RemoveUrl,\
                            RemoveAcento,\
                            RemoveSimbMoedas
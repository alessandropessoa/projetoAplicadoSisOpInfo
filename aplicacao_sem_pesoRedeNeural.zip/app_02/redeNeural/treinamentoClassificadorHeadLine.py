from sklearn.preprocessing import LabelEncoder
import tensorflow_datasets as tfds
import tensorflow as tf
from dataCleaning import RemoveAcento,  RemoveEmail, RemoveEspaco, RemoveUrl
from dataWrangling import RemoveStopW, Tokenizacao
from redeNeural import DCNN

from dataWrangling import seqLimpeza as seqLimp
from dataWrangling.gerenciadorDataframe import gerLetArqHL
import pandas as pd
import numpy as np



dataFrameSelecao= pd.DataFrame(columns=['identificador','headline','polaridade_headline'])


aux_df_neg = pd.DataFrame(gerLetArqHL('negativo'))
aux_df_pos = pd.DataFrame(gerLetArqHL('positivo'))

dataFrameTreino = pd.concat([aux_df_neg, aux_df_pos]).reset_index(drop = True)


lb = LabelEncoder()
polaridade_headline = lb.fit_transform(dataFrameTreino.polaridade_headline)
dataFrameTreino.polaridade_headline = polaridade_headline


print("Treinamenro será realizado com :\n")
print(dataFrameTreino.info())


with open('armazem/baseDados/colecaoPalLigPort/br-sem-acentos.txt') as arq:
    let = arq.readlines()
vocab_list= [x[:-1] for x in let]

# tokenizer = tfds.deprecated.text.SubwordTextEncoder.build_from_corpus(tokenizacao(textoPreLimpo3), target_vocab_size=2**16) #essa versao usar
tokenizer_1 = tfds.deprecated.text.SubwordTextEncoder.build_from_corpus(vocab_list, target_vocab_size=2**16)
tokenizer_1.save_to_file("redeNeural/vocabulario_headline_1")


dadosPreditorLimpo = [seqLimp(x) for x in dataFrameTreino.iloc[:,2].values]


dataCodificado = [tokenizer_1.encode(sentence) for sentence in dadosPreditorLimpo]

max_len = max([len(sentence) for sentence in dataCodificado])


data_inputs = tf.keras.preprocessing.sequence.pad_sequences(dataCodificado,
                                                            value = 0,
                                                            padding = 'post',
                                                            maxlen=max_len)

vocab_size = tokenizer_1.vocab_size

emb_dim = 200
nb_filters = 100
ffn_units = 256
batch_size = 64
nb_classes = len(dataFrameTreino.polaridade_headline.unique())

dropout_rate = 0.2
nb_epochs = 12

classificadorObj = DCNN(vocab_size=vocab_size, emb_dim=emb_dim, nb_filters=nb_filters,
            ffn_units=ffn_units, nb_classes=nb_classes, dropout_rate=dropout_rate)



if nb_classes == 2:
#caso eu tenha somente duas classes utilizamos o paramenro loss com binary, qie classificará de forma binaria
    classificadorObj.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
else:
#estamos utilizando o sparse_categorical_crossentropy caso o meu modelo seja utilizado 
# para classificar um numero maior de labels (classes)
    classificadorObj.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    

#local onde será salvo o modelo
checkpoint_path = "./redeNeural/checkpoint/headline"

#passando a classe que contém o modelo aser salvo
ckpt = tf.train.Checkpoint(dcnn=classificadorObj)

# passo o modelo salvo, o local onde será salvo e a quantidade dos ultimos modelos que serão salvos
# no  caso salvaremos os ultimos 5 modelos e seus pesos
ckpt_manager = tf.train.CheckpointManager(ckpt, checkpoint_path, max_to_keep=5) 
if ckpt_manager.latest_checkpoint:
    ckpt.restore(ckpt_manager.latest_checkpoint)
    print('Latest checkpoint restored')
  
  
#como utilizaremos o parametro validation_split: será separado percentual informado para realizar teste
#loss: 0.6771 - accuracy: 0.5263 -> valor de do erro(loss) e acuracia para base de TREINAMENTo nas respectiva epoca
#val_loss: 0.6829 - val_accuracy: 0.6667 -> valor de erro e acuracia para base de dado d TESTE nas respectiva epoca
print("*********************************************************************")
print("*********************************************************************")
print("*****************   INICIO DO TREINAMENTO   *************************")
print("*********************************************************************")
print("*********************************************************************")
history = classificadorObj.fit(data_inputs, dataFrameTreino.iloc[:,1].values,
                   batch_size = batch_size,
                   epochs = nb_epochs,
                   verbose = 1,
                   validation_split = 0.10) #utilizando esse parametro ja fazemos a validação separando 10% para teste e ja temos o val_acuracy
ckpt_manager.save()

print("*********************************************************************")
print("*********************************************************************")
print("*****************   FIM DO TREINAMENTO   ****************************")
print("*********************************************************************")
print("*********************************************************************")

print("\n\n\n")

#Avaliação do modelo
print("*********************************************************************")
print("*********************************************************************")
print("******************    INICIO DA AVALIAÇÃO   *************************")
print("*********************************************************************")
print("*********************************************************************")
print("\n\n")
print("Avaliação da HADLINE DA Noticia com polaridade negativa")

materia = """
Marinha realiza operação de combate a ilícitos em ilha da Baía de Guanabara
"""
materia="GLO: almirante fala grosso em reunião de comitê e ministro o substitui por civil"

teste_materia_prep = seqLimp(materia)
teste_ds = tokenizer_1.encode(teste_materia_prep)

polaridade =classificadorObj(np.array([teste_ds]),training=False).numpy()[0][0]
if polaridade >0.52:
    print("Positiva: ",polaridade)
else:
    print("Negativa: ",polaridade)
    
print("\n\n")
print("*********************************************************************")
print("*********************************************************************")
print("******************    FIM DA AVALIAÇÃO   *************************")
print("*********************************************************************")
print("*********************************************************************")
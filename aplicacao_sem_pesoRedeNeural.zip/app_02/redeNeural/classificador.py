import tensorflow as tf
from tensorflow.keras import layers


class DCNN(tf.keras.Model):

    def __init__(self,\
               vocab_size,     # tamanho do vocabulario
               emb_dim=128,    #dimensão(tamanho) da matriz de embedding
               nb_filters=50,  # quantidade de filtros em cada kernel ou seja: 50 para bigram, 50 para trigram e 50 para fourgran
               ffn_units=512,  # numero de neuronios da camada oculta da NN densa, a qtd de entrada, no nosso caso será atribuida automaticamente pelo tf pois é o memo tamanho da concatenação tf.concat no metrodo call()
               nb_classes=2,   #qtd de classes
               dropout_rate=0.1, #a porcentagem de neuronios que serão esquecidos para evitar o overfit
               training=True,
               name="dcnn"):
        super(DCNN, self).__init__(name=name)

        self.embedding = layers.Embedding(vocab_size, emb_dim)
      
    #nos diferentes tipos de filtros abaixo perceba que a unica coisa que muda
    # é o kernel_size=(2,3,4), poie define a qtd de palavras de contexto que serão utilizadas na convolução
    #note ainda que estamos utulizando Conv1D, desta forma o retorno será um vetor coluna(ou linha) 

    #um outro fato que vale lembrar é que o kernel_size=2 e não kernel_size=(2,2), pois difrente da convolucao
    #feita em imagens precisamos realizar a conv com todas as colunas para não perder info, logo a td de colls dos
    #filtros (self.bigram,self.trigram,self.fourgram e etc..) é a mesma qtd de colls da matriz de embedding (self.embedding
      
        self.bigram = layers.Conv1D(filters=nb_filters, kernel_size=2, padding='same', activation='relu')

        self.trigram = layers.Conv1D(filters=nb_filters, kernel_size=3, padding='same', activation='relu')

        self.fourgram = layers.Conv1D(filters=nb_filters, kernel_size=4, padding='same', activation='relu')

        self.pool = layers.GlobalMaxPool1D()

        self.dense_1 = layers.Dense(units = ffn_units, activation = 'relu')
        self.dropout = layers.Dropout(rate = dropout_rate)
        if nb_classes == 2:
            self.last_dense = layers.Dense(units = 1, activation = 'sigmoid')
        else:
            self.last_dense = layers.Dense(units = nb_classes, activation = 'softmax')

    def call(self, inputs, training):
        """
            Nesse metódo é realizado a ligação entre as camdas criadas nometodo construtor
        """
        x = self.embedding(inputs)
        x_1 = self.bigram(x)
        x_1 = self.pool(x_1)
      
        x_2 = self.trigram(x)
        x_2 = self.pool(x_2)
        
        x_3 = self.fourgram(x)
        x_3 = self.pool(x_3)

        #o parametro axis -1 abaixo setar o fato de que o vetor a ser concatenado pode ter ssua dimensão alterada
        #como setamos,  então o valor é o numero_de_diferentes_filtros filtro * nb_filters, no caso defeinios 3 diferente
        #tipos (bigram,trigram e fourgram) e cada tipo desse definimos uma quantidade nb_filters, ou seja se nb_filters=50
        #teremos 3*50 =150, seria um vetor linha ou coluna de tamanho 150
        
        merged = tf.concat([x_1, x_2, x_3], axis = -1) # (batch_size, 3 * nb_filters)

        #o vetor concatenado será submetido a rede neural densa
        merged = self.dense_1(merged)
        #o parametro training define a quantidade de neuronios que será esquecida a cada retropropagação
        merged = self.dropout(merged, training) 
        
        output = self.last_dense(merged)

        return output
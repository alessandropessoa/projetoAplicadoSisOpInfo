from sklearn.preprocessing import LabelEncoder
import tensorflow_datasets as tfds
import tensorflow as tf
from dataCleaning import RemoveAcento,  RemoveEmail, RemoveEspaco, RemoveUrl
from dataWrangling import RemoveStopW, Tokenizacao
from redeNeural import DCNN

from dataWrangling import seqLimpeza as seqLimp
from dataWrangling.gerenciadorDataframe import gerLetArq
import pandas as pd
import numpy as np

dataFrameSelecao= pd.DataFrame(columns=['identificador','texto','polaridade_texto'])


aux_df_neg = pd.DataFrame(gerLetArq('negativo'))
aux_df_pos = pd.DataFrame(gerLetArq('positivo'))

dataFrameTreino = pd.concat([aux_df_neg, aux_df_pos]).reset_index(drop = True)


lb = LabelEncoder()
polaridade_texto = lb.fit_transform(dataFrameTreino.polaridade_texto)
dataFrameTreino.polaridade_texto = polaridade_texto

print("Treinamenro será realizado com :\n")
print(dataFrameTreino.info())

#irá transformar cada palavra do texto em um numero, logo cada frase é vetor de numero que corresponde
# a cada palavra, o parametro target_vocab_size é o tamanho maximo de palavras que serão selecionadas para compor
# o vocabulario, por exemplo a lingua portuguesa tem cerca de 370 mil palvavras de acordo com agẽncia brasil(ebc) de comunicação
#um adulto conhecce cerca de 70 mil palavras do idioma, então ao treinar nosso modelo
#com 2**16=65536 é um tamanho interessante, o ideal é que esse valor seja acima de 2¹*16, mas aumenta o custo computacional
with open('armazem/baseDados/colecaoPalLigPort/br-sem-acentos.txt') as arq:
    let = arq.readlines()
vocab_list= [x[:-1] for x in let]

dadosPreditorLimpo2 = [seqLimp(x) for x in dataFrameTreino.texto.values]


#tokenizer = tfds.features.text.SubwordTextEncoder.build_from_corpus(textoPreLimpo6, target_vocab_size=2**16)
tokenizer = tfds.deprecated.text.SubwordTextEncoder.build_from_corpus(dadosPreditorLimpo2, target_vocab_size=2**16) #essa versao usar
tokenizer.save_to_file("redeNeural/vocabulario_1")

# tokenizer_1 = tfds.deprecated.text.SubwordTextEncoder.build_from_corpus(vocab_list, target_vocab_size=2**16)
# tokenizer_1.save_to_file("redeNeural/vocabulario_1")



# dadosPreditorLimpo = [seqLimp(x) for x in dataFrameTreino.iloc[:,2].values]

#data_inputs = [tokenizer.encode(sentence) for sentence in dadosPreditorLimpo] #esse tokennizador utiliza o corpus construidoa apenas com palacras existentes na baseDados
#o dataCodificado é construido a partir de corpus feito com todas as palavras da lingua portuguesa tokenizer_1
# dataCodificado = [tokenizer_1.encode(sentence) for sentence in dadosPreditorLimpo]

dataCodificado = [tokenizer.encode(sentence) for sentence in dadosPreditorLimpo2 ]

max_len = max([len(sentence) for sentence in dataCodificado])

#o processo de padding, faz com que todos os vetores tenham o mesmo tamanho, e como cada 
#palavra  será mapeada conforme o corpus construido, no caso concreto o corpus criado com as palavras da lingua portuguesa tokenizer_1,  
#cada palavra é um numero, ou seja seria um vetor com n-elementos sendo cada elemento uma palavra (cada dumensão) e o  vetor o texto
data_inputs = tf.keras.preprocessing.sequence.pad_sequences(dataCodificado,
                                                            value = 0,
                                                            padding = 'post',
                                                            maxlen=max_len)

# vocab_size = tokenizer_1.vocab_size
vocab_size = tokenizer.vocab_size
emb_dim = 200
nb_filters = 100
ffn_units = 256
batch_size = 64
nb_classes = len(dataFrameTreino.polaridade_texto.unique())

dropout_rate = 0.2
nb_epochs = 12

classificadorObj = DCNN(vocab_size=vocab_size, emb_dim=emb_dim, nb_filters=nb_filters,
            ffn_units=ffn_units, nb_classes=nb_classes, dropout_rate=dropout_rate)



if nb_classes == 2:
#caso eu tenha somente duas classes utilizamos o paramenro loss com binary, qie classificará de forma binaria
    classificadorObj.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
else:
#estamos utilizando o sparse_categorical_crossentropy caso o meu modelo seja utilizado 
# para classificar um numero maior de labels (classes)
    classificadorObj.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    

#local onde será salvo o modelo
checkpoint_path = "./redeNeural/checkpoint/texto"

#passando a classe que contém o modelo aser salvo
ckpt = tf.train.Checkpoint(dcnn=classificadorObj)

# passo o modelo salvo, o local onde será salvo e a quantidade dos ultimos modelos que serão salvos
# no  caso salvaremos os ultimos 5 modelos e seus pesos
ckpt_manager = tf.train.CheckpointManager(ckpt, checkpoint_path, max_to_keep=5) 
if ckpt_manager.latest_checkpoint:
    ckpt.restore(ckpt_manager.latest_checkpoint)
    print('Latest checkpoint restored')
  
  
#como utilizaremos o parametro validation_split: será separado percentual informado para realizar teste
#loss: 0.6771 - accuracy: 0.5263 -> valor de do erro(loss) e acuracia para base de TREINAMENTo nas respectiva epoca
#val_loss: 0.6829 - val_accuracy: 0.6667 -> valor de erro e acuracia para base de dado d TESTE nas respectiva epoca
print("*********************************************************************")
print("*********************************************************************")
print("*****************   INICIO DO TREINAMENTO   *************************")
print("*********************************************************************")
print("*********************************************************************")
history = classificadorObj.fit(data_inputs, dataFrameTreino.iloc[:,1].values,
                   batch_size = batch_size,
                   epochs = nb_epochs,
                   verbose = 1,
                   validation_split = 0.10) #utilizando esse parametro ja fazemos a validação separando 10% para teste e ja temos o val_acuracy
ckpt_manager.save()

print("*********************************************************************")
print("*********************************************************************")
print("*****************   FIM DO TREINAMENTO   ****************************")
print("*********************************************************************")
print("*********************************************************************")

print("\n\n\n")

#Avaliação do modelo
print("*********************************************************************")
print("*********************************************************************")
print("******************    INICIO DA AVALIAÇÃO   *************************")
print("*********************************************************************")
print("*********************************************************************")
print("\n\n")
print("Avaliação de Noticia com polaridade negativa")
materia = """
O governo federal gastou R$ 2,6 bilhões, em valores corrigidos pela inflação, em 49 operações do tipo GLO (Garantia da Lei e da Ordem) realizadas pelas Forças Armadas de janeiro de 2010 a dezembro de 2018, segundo dados do Ministério da Defesa.

O assassinato com 80 tiros, por militares, do músico Evaldo Rosa, 51, no último dia 7, ocorreu fora de uma GLO. Ele dirigia com a família para um chá de bebê em Guadalupe, na zona norte do Rio, quando seu carro foi alvejado por balas disparadas pela equipe militar. O Exército determinou a prisão em flagrante de 10 dos 12 oficiais envolvidos no assassinato. 

O crime trouxe novamente à tona a discussão sobre a capacidade e o treinamento de militares em atividades típicas de policiais militares, como o patrulhamento de ruas.

Vídeos publicados nas redes sociais mostram moradores da região criticando os militares logo após os disparos. Eles dizem que o carro da família foi confundido com o de bandidos.

Do total gasto pela União no período de nove anos, quase a metade, ou 49%, foi para três eventos esportivos, todos no primeiro mandato da presidente Dilma Rousseff (PT-MG): Copa das Confederações, em 2013 (R$ 572,7 milhões), os V Jogos Mundiais Militares, em 2011 (R$ 590,8 milhões), e a Copa do Mundo, em 2014 (R$ 109,2 milhões).

As GLOs variaram de meses a alguns dias de duração. Em 24 de maio de 2017, por exemplo, o ex-presidente Michel Temer (MDB) convocou as Forças Armadas para conterem protesto contra a reforma da Previdência, em Brasília. Organizado por centrais sindicais, o ato culminou em confronto com a PM e depredação de ministérios. Na ocasião, os militares empregaram R$ 1,88 milhão e mobilizaram 1,8 mil homens e mulheres na "Operação Esplanada", que acabou no dia seguinte.

Embora divirjam quanto aos prós e contras das GLOs já realizadas, especialistas ouvidos pela Folha concordam que é preciso evitar a banalização desse tipo de operação, que deveria ser, na opinião deles, pontual, curta e rara.
"""
# teste_materia_prep = seqLimp(materia)
# teste_ds = tokenizer_1.encode(teste_materia_prep)

teste_materia_prep = seqLimp(materia)
teste_ds = tokenizer.encode(teste_materia_prep)

polaridade =classificadorObj(np.array([teste_ds]),training=False).numpy()[0][0]
if polaridade >0.523:
    print("Positiva: ",polaridade)
else:
    print("Negativa: ",polaridade)
    
print("\n\n")
print("*********************************************************************")
print("*********************************************************************")
print("******************    FIM DA AVALIAÇÃO   *************************")
print("*********************************************************************")
print("*********************************************************************")
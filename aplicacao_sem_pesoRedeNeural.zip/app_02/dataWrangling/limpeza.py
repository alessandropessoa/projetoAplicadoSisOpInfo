from typing import Type
from interfaces import TipoLimpezaInterface


class Limpar():
    def __init__(self):
        self._operacoes = []
        self._texto=""
        self._textoTratado=""
    
    def tipoOperacao(self,operacao):
        if isinstance(operacao,list):
            self._operacoes = operacao
        elif isinstance(operacao,TipoLimpezaInterface):
            self._operacoes.append(operacao)
            
    def _instanciarObjetos(self,obj:Type[TipoLimpezaInterface]):
        return obj()
            
    def setTexto(self,texto):
        self._texto =texto.lower()
        
    def getTexto(self)->str:
        return self._textoTratado
        
    def executar(self,opcao='padrao'):
        aux =self._texto
        for x in self._operacoes:
            obj = self._instanciarObjetos(x)
            obj.setTexto(aux)
            aux = obj.executar()
          
        self._textoTratado=aux
        return self.getTexto()
            
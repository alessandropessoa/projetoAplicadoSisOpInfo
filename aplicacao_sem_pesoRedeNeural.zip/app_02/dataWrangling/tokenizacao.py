import nltk
from typing import Type
import os

class Tokenizacao():
    def __init__(self):      
        self._texto = ""
        self._textoTratado = ""
         
    def setTexto(self,texto:str):
        if texto!="":
            self._texto = texto
        else: 
            raise "Não é permitido texto vazio"
        
    def _setTextoTratado(self,texto:str):
        """_summary_

        Args:
            texto (list):Recebe uma lista de palavras, em geral após processo de tokenização
        """
        self._textoTratado = texto
        
    def getTexto(self)->str:
        return self._textoTratado    
    
    def executar(self):
        self._setTextoTratado(nltk.word_tokenize(self._texto))
        return self.getTexto()
    



        
        
        
import pandas as pd
import os

def criaDF(df):
    """cria Dataframe conforme extensão csv,json ou excel

    Args:
        df (_type_): recebe o caminho (path) de arquivo em csv,json ou excel

    Returns:
        _type_: dataframe pandas
    """
    if isinstance(df,str):
        if df.split('.')[1] == 'csv':
            dataFrame = pd.read_csv(df)
            
        elif df.split('.')[1] == 'json':
            dataFrame = pd.read_json(df)
            
        elif (df.split('.')[1] == 'xls') or ((df.split('.')[1] == 'xlsx')):
            dataFrame = pd.read_excel(df)    
    return dataframe
            


def leitor(texto):
    try:
        return texto.encode('latin-1').decode('utf-8')
    except Exception as error:
        print('Houve erro - ',texto,error)
        pass
    
    
    
def gerLetArq(polaridade_texto,path_db_treinamento = "armazem/baseDados/treinamento/texto/"):
    aux_dict = {'identificador':[],'polaridade_texto':[],'texto':[]}
    
    for arq in os.listdir(f'{path_db_treinamento}{polaridade_texto}'):
        
        identificador, arqN = arq.split('_')
        polaridade_texto = arqN.split('.')[0]
        
        with open(f'{path_db_treinamento}{polaridade_texto}/{arq}', 'r') as ler:
            texto = ler.read()
            # texto = leitor(ler.read())
            
        aux_dict['identificador'].append(identificador)
        aux_dict['polaridade_texto'].append(polaridade_texto)
        aux_dict['texto'].append(texto)
        
    return aux_dict


def gerLetArqHL(polaridade_headline,path_db_treinamento = "armazem/baseDados/treinamento/headline/"):
    aux_dict = {'identificador':[],'polaridade_headline':[],'headline':[]}
    
    for arq in os.listdir(f'{path_db_treinamento}{polaridade_headline}'):
        
        identificador, arqN = arq.split('_')
        polaridade_headline = arqN.split('.')[0]
        
        with open(f'{path_db_treinamento}{polaridade_headline}/{arq}', 'r') as ler:
            headline = ler.read()
            # texto = leitor(ler.read())
            
        aux_dict['identificador'].append(identificador)
        aux_dict['polaridade_headline'].append(polaridade_headline)
        aux_dict['headline'].append(headline)
        
    return aux_dict





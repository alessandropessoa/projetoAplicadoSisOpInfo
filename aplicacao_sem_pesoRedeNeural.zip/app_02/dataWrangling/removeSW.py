from nltk.corpus import stopwords
from interfaces import TipoLimpezaInterface

class RemoveStopW(TipoLimpezaInterface):
    """Remove Stop woeds conforme idioma

    Args:
        TipoLimpezaInterface (_type_): _description_
    """
    def __init__(self):      
        self.stopwords = stopwords
        self._texto = []
        self._textoTratado = ""
         
    def setTexto(self,texto:list):
        if texto!=[]:
            self._texto = texto
        else: 
            raise "Não é permitido texto vazio"
        
    def _setTextoTratado(self,texto:list):
        """_summary_

        Args:
            texto (list):Recebe uma lista de palavras, em geral após processo de tokenização
        """
        self._textoTratado = texto
        
    def getTexto(self)->str:
        return self._textoTratado    
    
    def executar(self,opcao='portuguese'):
        newwords = [word for word in self._texto if word not in self.stopwords.words(opcao)]
        self._setTextoTratado(' '.join(newwords))
        return self.getTexto()
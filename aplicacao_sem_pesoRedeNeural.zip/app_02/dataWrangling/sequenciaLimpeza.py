from dataWrangling import Limpar
from dataCleaning import RemoveAcento,  RemoveEmail, RemoveEspaco, RemoveUrl,RemoveNumeros,RemoveSimbMoedas,RemovePontuacao
from dataWrangling import RemoveStopW, Tokenizacao


def seqLimpeza(texto:str):
    limpezaDados    = Limpar()
    tokenizacao     = Tokenizacao()
    removeSTOPWord  = RemoveStopW()

    limpezaDados.tipoOperacao([RemoveSimbMoedas, RemoveAcento,  RemoveEmail, RemoveUrl,RemoveNumeros,RemovePontuacao, RemoveEspaco])
    
    limpezaDados.setTexto(texto)
    lp = limpezaDados.executar()

    tokenizacao.setTexto(lp)
    tk = tokenizacao.executar()

    removeSTOPWord.setTexto(tk)
    textoTrasformado = removeSTOPWord.executar()
     
    return textoTrasformado
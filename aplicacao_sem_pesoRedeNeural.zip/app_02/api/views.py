from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from redeNeural import DCNN
import pymongo as mongo 
from gerenciadorBancoDeDados import GerenteMongo
from webScraping import Scraping
from controler import armDados, ltsc
from bson.objectid import ObjectId
from dataWrangling import seqLimpeza as seqLimp
from dataWrangling.gerenciadorDataframe import gerLetArq

import os


mongo = GerenteMongo()
mongo.setBanco('teste')
mongo.setColecao('scrap')


def classificador(materia):
    import tensorflow as tf
    import tensorflow_datasets as tfds
    import numpy as np
    
    materia = " ".join(materia)
    vocab_size = 245604

    emb_dim = 200
    nb_filters = 100
    ffn_units = 256
    batch_size = 64
    nb_classes = 2

    dropout_rate = 0.2
    nb_epochs = 12
    
    classificadorObj = DCNN(vocab_size=vocab_size, emb_dim=emb_dim, nb_filters=nb_filters,
            ffn_units=ffn_units, nb_classes=nb_classes, dropout_rate=dropout_rate)
    
    if nb_classes == 2:
    #caso eu tenha somente duas classes utilizamos o paramenro loss com binary, qie classificará de forma binaria
        classificadorObj.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    else:
    #estamos utilizando o sparse_categorical_crossentropy caso o meu modelo seja utilizado 
    # para classificar um numero maior de labels (classes)
        classificadorObj.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    
    #local onde será salvo o modelo
    checkpoint_path = f"{os.getcwd()}/redeNeural/checkpoint/texto/checkpoint"
    # print(checkpoint_path)
    # print(os.listdir(checkpoint_path))
    #passando a classe que contém o modelo a ser salvo
    ckpt = tf.train.Checkpoint(dcnn=classificadorObj)

    ckpt.restore(tf.train.latest_checkpoint(checkpoint_path))
    print("*********************************************************************")
    print("*********************************************************************")
    print('**************   Ultimos checkpoints restaurados.   *****************'.upper())
    print("*********************************************************************")
    print("*********************************************************************")


    #irá transformar cada palavra do texto em um numero, logo cada frase é vetor de numero que corresponde
    # a cada palavra, o parametro target_vocab_size é o tamanho maximo de palavras que serão selecionadas para compor
    # o vocabulario, por exemplo a lingua portuguesa tem cerca de 370 mil palvavras de acordo com agẽncia brasil(ebc) de comunicação
    #um adulto conhecce cerca de 70 mil palavras do idioma, então ao treinar nosso modelo
    #com 2**16=65536 é um tamanho interessante, o ideal é que esse valor seja acima de 2¹*16, mas aumenta o custo computacional
    with open(f"{os.getcwd()}/armazem/baseDados/colecaoPalLigPort/br-sem-acentos.txt") as arq:
        let = arq.readlines()
    vocab_list= [x[:-1] for x in let]
    

    tokenizer_1 = tfds.deprecated.text.SubwordTextEncoder.build_from_corpus(vocab_list, target_vocab_size=2**16)
    tokenizer_1.save_to_file("redeNeural/vocabulario_1")
    
    teste_materia_prep = seqLimp(materia)
    teste_ds2 = tokenizer_1.encode(teste_materia_prep)
    polaridade2 =classificadorObj(np.array([teste_ds2]),training=False).numpy()[0][0]
    
    print("Matéria 02")
    if polaridade2 >0.51:
        print("Positiva: ",polaridade2)
    else:
        print("Negativa: ",polaridade2)
        
    return polaridade2
        
        

def api(requests,arg):
    
    aux = mongo.encontrarDado({'_id':ObjectId(arg)})
    ret = classificador(materia=aux)
    data=[{'resultadoClassificacao':f'{ret}'}]

    return JsonResponse(data,safe=False)

def teste(requests,arg):
    aux = mongo.encontrarDado({'_id':ObjectId(arg)})
    return HttpResponse(f'<h1>SisOpInfo  </h1><p><b>ObjectId</b> na base de dados: {arg}</p> <p>{aux}</p>')


from django.urls import path
from . import views

app_name='api'

urlpatterns = [
    path('classificador/<str:arg>/',views.api, name='api'),
    path('teste/<str:arg>/',views.teste)
]
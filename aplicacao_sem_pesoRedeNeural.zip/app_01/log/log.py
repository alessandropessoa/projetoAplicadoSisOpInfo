import logging
from datetime import datetime
import os
from decouple import config
 
class Log():
    def _inserirEvento(self,evento,nomeArq):
        nomeArq = nomeArq.replace('/',"")
        path =  os.getcwd()+config('path_db_log')
        with open(f'{path}{nomeArq}.txt','a') as arq:
            arq.writelines(f'\n {evento}')
            
    def criarEvento(self,informe:str):
        data,hora= self.dataHora()
        evento = {'evento':informe,'data':data,'hora':hora}
        evt = "|%(evento)s | %(data)s %(hora)s |"%(evento)
        self._inserirEvento(evento=evt,nomeArq=data)
        
    def dataHora(self)->tuple:
        data_atual = datetime.today()
        data,hora  = data_atual.strftime("%d/%m/%Y %H:%M").split(" ")   
        return data,hora

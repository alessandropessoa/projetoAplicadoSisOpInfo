from . import gerenteBancoDadosMongo
from webScraping import Scraping 
from webScraping import ExtratorParagrafo
from webScraping import Requisicao

sc = Scraping()
sc.setUrlRaspagem(url)
sc.setReq(Requisicao)
sc.setExt(ExtratorParagrafo)
sc.raspar()
print(sc.getConteudo())
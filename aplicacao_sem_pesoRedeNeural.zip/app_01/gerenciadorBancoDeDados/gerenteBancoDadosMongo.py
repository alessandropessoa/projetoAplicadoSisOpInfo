from decouple import config
import pymongo as mongo
import os

class GerenteMongo():
    def __init__(self):
        _url = f"mongodb://{config('usuarioMongo')}:{config('senhaBaseDadosMongo')}@{config('urlBaseDadosMongo')}:{config('portaBaseDadosMongo')}/"
        self.cliente = mongo.MongoClient(_url)
        self._banco = None
        self._colecao = None
        self._documento=None
        print("coleções Existentes: ",self.cliente.list_database_names())
        
        
    def verificarSeBancoExiste(self,nomeBanco:str)->str:
        """verifica se existe banco"""
        if nomeBanco in self.cliente.list_database_names():
            return 1
        return 0
    
    def verificarSeColecaoExiste(self,nomeColecao:str):
        """Verifica se existe uma coleção
        Args:
            banco (str): Nome da coleção a ser verfica no banco
            nomeColecao (str): nome do banco onde será verificado se existe coleção

        Returns:
            int: Retorna 1 se houver coleção e 0 senão houver
        """
        if nomeColecao in self._banco.list_collection_names():
            return 1
        return 0
    
    def setBanco(self,nomeBanco:str):
        self._banco = self.cliente[nomeBanco]
    
    def getBanco(self):
        return self._banco
    
    def setColecao(self,nomeColecao):
        self._colecao = self._banco[nomeColecao]
        
    def getColecao(self)->str:
        return self._colecao
    
    def getObjectIdDoc(self)->str:
        return self._documento
        
    def inserirDado(self,dado:dict):
        self._documento = self._colecao.insert_one(dado)
        
    def encontrarDado(self,filtro:dict)->dict:
        return self._colecao.find_one(filtro)
    
    def inserirMuitosDados(self,dados:list):
        self._colecao.insert_many(dados) 
    
    def encontrarMuitosDados(self,filtro:dict)->list:
        documentos =[]
        cursor = self._colecao.find(filtro)
        for documento in cursor:
            documentos.append(documento)
        return documentos    
        
    def deletarDado(self,filtro:dict):
        self._colecao.delete_one(filtro)
        
    def deletarMuitosDados(self,filtro:dict):
        self._colecao.delete_many(filtro)
        
    def atualizarDado(self,filtro:dict, atualizacoes:dict):
        self._colecao.update_one(filtro,atualizacoes)
        
    def atualizaMuitosDados(self,filtro:dict, atualizacoes:dict):
        self._colecao.update_many(filtro,atualizacoes)
        
    def inserirDocumento(self,documentoCSV):
        import csv
        
        with open(documentoCSV,'r') as arq:
            linhaCsv = csv.DictReader(arq)      
            linhas = [x for x in linhaCsv]
            
        self.inserirMuitosDados(dados=linhas)
                
import streamlit as st
from gerenciadorBancoDeDados import GerenteMongo
from webScraping import Scraping
from controler import armDados, ltsc
from bson.objectid import ObjectId
import time
from streamlit_js_eval import streamlit_js_eval
import requests
import json
from decouple import config 

#remove menu de configuração 
st.set_page_config(page_title="SisOPInfo", page_icon=":shark:", layout="centered", initial_sidebar_state="auto")


mongo = GerenteMongo()
mongo.setBanco('teste')
mongo.setColecao('scrap')

with st.container(border=True):
    url = st.text_input("Informe URL",help="Pressione Enter Para Executar Scrap")
    url_trat  = url.strip()
    if url_trat != "":
        texto, status = Scraping(url=url_trat).raspar()
        texto = " ".join(texto)

        # armDados.armDados(texto=texto,url=url)

        if ret :=mongo.encontrarDado({'url':f'{url_trat}'}) :
            st.write("Já existe um conteudo dessa URL")
            
            texto_atual         = st.text_area("TEXTO", value=texto, height=300)
            alcance             = st.selectbox("Alcance da Informação",('Internacional','Nacional','Local'))
            grupoEmpresarial    = st.text_input("Grupo Empresarial")
            viesPol             = st.selectbox("Viés Politico da Fonte de Noticía",('Esquerda','Centro Esquerda','Centro','Centro Direita','Direita'))
            autores             = st.text_input("Autor(es) da Reportagem",help="Separe os nomes por ','")  

            containerClassif = st.container(border=True)
            containerClassif.markdown("Classificação Operador Humano")
            
 
            pol_texto       = containerClassif.text_input("Polaridade Texto")
            pol_headline    = containerClassif.text_input("Polaridade Headline")
            
            containerClassifIA = st.container(border=True)
            containerClassif.markdown("Classificação por IA")
            id_dado_db = mongo.encontrarDado({'url':f'{url_trat}'})['_id']
            print("Valor id -> ",id_dado_db)
            aux_req = requests.get(f'http://{config("urlApiApp002")}:8001/api/classificador/{id_dado_db}')
            aux_req_resultado = json.loads(aux_req.text[1:-1])['resultadoClassificacao']
            # pol_textoIA       = containerClassif.text_input("Polaridade Texto IA")

                
            pol_textoIA =containerClassif.info(f'Polaridade texto  IA {aux_req_resultado}')
            pol_headlineIA    = containerClassif.text_input("Polaridade Headline IA")
            
            if pol_texto !="" and pol_textoIA!="" :
                statusClassificacao ="Humano e IA"
                
            elif pol_texto =="" and pol_textoIA!="": 
                statusClassificacao ="IA"
                
            elif pol_texto !="" and pol_textoIA=="": 
                statusClassificacao ="Humano"
            else:
                statusClassificacao = 'Não Classificado'
                
                           
            col1, col2 = st.columns([3, 1])
            
            with col1:
                if btn := st.button("SALVAR"):
                    mongo.atualizarDado({'url':url_trat}, {'$set':{'texto':texto_atual,'alcance':alcance,\
                       'grupoEmpresarial':grupoEmpresarial, 'viesPoliticoFonte':viesPol, 'autores':autores,\
                        'polaridadeTexto':pol_texto, 'polaridadeHeadline':pol_headline,\
                        'polaridadeTextoIA':pol_textoIA, 'polaridadeHeadlineIA':pol_headlineIA,\
                        'statusClassificacao':statusClassificacao}}) 
                    st.success("Conteudo Atualizado")
            with col2:   
                if btn := st.button("DELETAR SCRAP"):
                    mongo.deletarDado({'url':url_trat}) 
                    st.success("Webcraping apagado da Base de Dados")
                    

        else:
            st.warning("Ainda não existe um scrap dessa URL")
            if btn_arm := st.button("Arnazenar"):
                dados ={'texto':texto, 'url':url}
                armDados.armDados(dados)
                st.success("Texto Armazenado com sucesso!")
                time.sleep(2)
                streamlit_js_eval(js_expressions="parent.window.location.reload()")
            
            
            
            
            
        
        
        
        

            


    


print("FIM")
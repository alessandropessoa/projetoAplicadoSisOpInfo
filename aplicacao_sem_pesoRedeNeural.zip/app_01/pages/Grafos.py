import streamlit as st
from streamlit_agraph import agraph, Node, Edge, Config
from streamlit_agraph.config import Config, ConfigBuilder

st.set_page_config(page_title="SisOPInfo-OODA", page_icon=":shark:", layout="wide", initial_sidebar_state="auto")

nodes = []
edges = []

nodes.extend([ Node(id='Observar', label='Observar', size=10, color='blue'),
    Node(id='Orientar', label='Orientar', size=10, color='green'),
    Node(id='Decidir', label='Decidir', size=10, color='yellow'),
    Node(id='Agir', label='Agir', size=10, color='red')
    ])

nodes.extend(
       [Node(id='IdMongo_01', label='Tanques nas calçadas', size=10, color='blue'),
       Node(id='IdMongo_02', label='Ineficacia da Operação', size=10, color='blue'),
       Node(id='IdMongo_03', label='Midia vies politico contrario governo', size=10, color='green'),
       Node(id='IdMongo_04', label='retirar vtrs calçada ', size=10, color='yellow'),
       Node(id='IdMongo_05', label='coletiva de impresa', size=10, color='red'),
       ])


edges.extend([
       Edge(source='Observar', target='Orientar',label="Narrativa?"),
       Edge(source='Orientar', target='Decidir',label="nalises e compreensões?"),
       Edge(source='Decidir', target='Agir',label="solução a ser adotada?"),
       Edge(source='Agir', target='Observar' ,label="opções Disponiveis? mudanças ?")
    ])

edges.extend([
       Edge(source='IdMongo_01', target='Observar',label="CampoNoBancoDadoTextoDaAcao"),
       Edge(source='IdMongo_02', target='Observar',label="CampoNoBancoDadoTextoDaAcao"),
       Edge(source='IdMongo_03', target='Orientar',label="CampoNoBancoDadoTextoDaAcao"),
       Edge(source='IdMongo_04', target='Decidir',label="CampoNoBancoDadoTextoDaAcao"),
       Edge(source='IdMongo_05', target='Agir',label="CampoNoBancoDadoTextoDaAcao"),
])  


config_builder = ConfigBuilder(nodes)
config = config_builder.build()


config.save("grafoOODA.json")


config = Config(from_json="config.json")


return_value = agraph(nodes=nodes, 
                      edges=edges, 
                      config=config)
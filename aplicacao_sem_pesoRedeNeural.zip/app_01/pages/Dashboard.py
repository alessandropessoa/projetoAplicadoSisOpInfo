import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

st.set_page_config(page_title="SisOPInfo-Dashboard", page_icon=":shark:", layout="centered", initial_sidebar_state="auto")

chart_data = pd.DataFrame(
   {"Data": np.random.randn(20), "Polaridade Texto": np.random.randn(20)}
)



data ={
    'ObjectId':["ObjectId('65d4e15d2118274b84a423a3')", "ObjectId('65d4ce382118274b84a4239b')","ObjectId('1651965161898918191)",\
        "ObjectId('156sds65v1sfs6e516cwe')","ObjectId('erfe5rveve5rv1erv6516')","ObjectId('asdcavsec6516sa51ec')","ObjectId('asdcavsec6516sa51ec5')","ObjectId('asdcavsec6516sa51ec5df')"],
    'Polaridade Texto':['positiva','negativa','positiva','positiva','negativa','negativa','negativa','negativa'],
    'Polaridade Headline':['positiva','positiva','positiva','positiva','negativa','negativa','negativa','negativa'],
    'Vies Politico Fonte':['esquerda','direita','centro esquerda','esquerda','direita','centro','direita','negativa'],
    'Vies Politico Governo':['esquerda','esquerda','esquerda','esquerda','esquerda','esquerda','direita','negativa'],
    'Data':['10/11/2023','12/11/2023','12/11/2023','12/11/2023','13/11/2023','16/11/2023','17/11/2023','18/11/2023'],
    
  
    
}
df = pd.DataFrame(data)


df = df.drop(columns=['ObjectId'])


st.title('Dashboard ')



df_text_pos= len(df[df['Polaridade Texto']=='positiva'])
df_text_neg= len(df[df['Polaridade Texto']=='negativa'])
total_not = len(df['Polaridade Texto'])

fig = go.Figure(data=[go.Pie(labels=['positiva','negativa'], values=[df_text_pos,df_text_neg], pull=[0, 0, 0.2, 0])])
fig.add_annotation(
    x=0.5,
    y=0.5,
    text="OODA" , 
    showarrow=False,
    font=dict(size=20)
)

fig.update_traces(hole=.4, hoverinfo="label+percent+name")


container =st.container(border=True)
col1, col2, col3, col4= container.columns(4)
with st.container():
    col1.container(border=True).write(f"Total: {total_not}")
    col1.container(border=True).write(f"Noticias Fratricidicas: 1")
    col2.metric('Noticias Positivas',value=df_text_pos)
    col2.metric('Noticias Negativas',value=df_text_neg)
with st.container():
    col3.container(border=True).write("Ultimas 24h")
    col3.container(border=True).write("Total: 6 ")
    col3.container(border=True).write(f"Noticias Fratricidicas: 1")
    col4.metric('Noticias Negativas',value=2, delta="-1", delta_color='normal')
    col4.metric('Noticias Positivas',value=4, delta=f"2", delta_color='normal')


with st.container():
    st.plotly_chart(fig, theme="streamlit", use_container_width=True)


st.subheader('Histograma de Evolução das Noticias ')
st.bar_chart(
   data, x="Data", y="Polaridade Texto", color="Polaridade Texto"
)


st.write(df)
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="SisOPInfo-Planejamento", page_icon=":shark:", layout="centered", initial_sidebar_state="auto")

# Definição das variáveis e seus conjuntos fuzzy
gravidade = ['Catastrófica', 'Severa', 'Média', 'Leve']
probabilidade = ['Muito Provável', 'Provável', 'Pouco Provável', 'Improvável']
impacto = ['Crítico', 'Alto', 'Moderado', 'Baixo', 'Desprezível']

# Função para gerar matriz de pertinência
def matriz_pertinencia(variavel, valores):
  matriz = []
  for valor in valores:
    linha = []
    for v in variavel:
      if v == valor:
        linha.append(1)
      else:
        linha.append(0)
    matriz.append(linha)
  return np.array(matriz)

# Matrizes de pertinência
matriz_gravidade = matriz_pertinencia(gravidade, ['Catastrófica', 'Severa', 'Média', 'Leve'])
matriz_probabilidade = matriz_pertinencia(probabilidade, ['Muito Provável', 'Provável', 'Pouco Provável', 'Improvável'])
matriz_impacto = matriz_pertinencia(impacto, ['Crítico', 'Alto', 'Moderado', 'Baixo', 'Desprezível'])

# Função para inferência fuzzy
def inferencia_fuzzy(gravidade, probabilidade):
  # Combinação das matrizes de pertinência
  global matriz_combinada  # Declare a variável como global para usar dentro da função
  matriz_combinada = np.dot(matriz_gravidade, matriz_probabilidade)

  # Cálculo do centro de massa
  impacto_max = np.argmax(matriz_combinada, axis=1)
  impacto_fuzzy = []
  for i in range(len(impacto_max)):
    impacto_fuzzy.append(impacto[impacto_max[i]])

  return impacto_fuzzy

# Dicionário para mapeamento de cores
cores = {
  'Crítico': '#FF0000',
  'Alto': '#FF8000',
  'Moderado': '#FFFF00',
  'Baixo': '#00FF00',
  'Desprezível': '#008000'
}

# Interface do Streamlit

st.title('Classificação de Impacto com Lógica Fuzzy')

# Seleção da gravidade e probabilidade
gravidade_selecionada = st.selectbox('Gravidade', gravidade)
probabilidade_selecionada = st.selectbox('Probabilidade de Ocorrência', probabilidade)

# Cálculo do impacto
impacto_fuzzy = inferencia_fuzzy([gravidade_selecionada], [probabilidade_selecionada])[0]

# Apresentação do resultado
st.markdown(f'**Impacto:** {impacto_fuzzy}')

# Mapa de calor com Plotly
mapa_calor = px.imshow(matriz_combinada, x=gravidade, y=probabilidade, color_continuous_scale='Viridis',
                      labels={'x': 'Gravidade', 'y': 'Probabilidade de Ocorrência', 'color': 'Impacto'})
mapa_calor.update_layout(title='Mapa de Calor do Impacto', font=dict(size=12))

# Adição de legenda
for i in range(len(impacto)):
  mapa_calor.add_shape(
    type='line',
    x0=i,
    y0=-0.5,
    x1=i,
    y1=len(probabilidade)-0.5,
    line=dict(color=cores[impacto[i]], width=3)
  )

st.plotly_chart(mapa_calor)


import streamlit as st

def tt(texto):
    texto_atual= st.text_area("TEXTO", value=texto, height=300)
    print('val txt  ',texto_atual)
    return texto_atual
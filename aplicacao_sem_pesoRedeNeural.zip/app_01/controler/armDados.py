from gerenciadorBancoDeDados import GerenteMongo
from datetime import datetime

def armDados(dados):
    data_atual = datetime.today()
    auxDado= { 'dataHoraCriacao':data_atual,'dataHoraAtualizacao':data_atual, \
        'texto':"", 'url':"", 'usadoParaTreino':False,'alcance':'','grupoEmpresarial':'',\
         'viesPoliticoFonte':'','autores':''  }
    
    
    mongo = GerenteMongo()
    mongo.setBanco('teste')
    mongo.setColecao('scrap')
    
    data_atual  = datetime.today()
    # data, hora  = data_atual.strftime("%d/%m/%Y %H:%M").split(" ")  

    for x in dados.keys():
        auxDado[x] = dados[x]
     
    
    mongo.inserirDado(dado= auxDado)
    return mongo.getObjectIdDoc()


def atualizaDados():
    ...
from webScraping import Scraping
import streamlit as st

def ltsc(url):
    texto = Scraping(url=url).raspar()
    return " ".join(texto[0])

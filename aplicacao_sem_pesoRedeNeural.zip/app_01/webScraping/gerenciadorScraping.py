from webScraping import Scraping


class GerenciadorSC():
    @staticmethod
    def criar(objReq,objExt, url="", )->Scraping:
        if url !="":
            req =objReq()
            req.copiar(url=url)
            paginaWeb = req.paginaWebTratada()
            
            ext = objExt()
            ext.getConteudo(paginaWeb=paginaWeb)
            
        else:
            req = objReq
            ext = objExt
            
        return Scraping(url=url, req=req , ext=ext)
        
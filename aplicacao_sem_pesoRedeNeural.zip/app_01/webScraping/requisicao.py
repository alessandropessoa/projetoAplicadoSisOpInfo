import requests

class Requisicao():
    def __init__(self):
        self._paginaWeb = ""
        self._status:int = 0
        self._url:str=""
        self.pagHtml=""
         
    def paginaWebTratada(self)->str:
        if self._status==0:
            return "Essa url não existe ou você esta sem rede."
        return self._paginaWeb.text
    
    def copiar(self,url:str=""):
        try:
            self._url = url

            self._paginaWeb =requests.get(url)
            self.pagHtml= self._paginaWeb.content.decode()
            self._status = self._paginaWeb.status_code     
            
        except Exception as error:
            print(f"classe Requisicao() garrou {self._status}")
            print(error)
            
    def getStatusRequisicao(self)->str:
        return self._status
    
    def getUrl(self)->str:
        return self._url
        
        
    
from bs4 import BeautifulSoup 

class ExtratorParagrafo():
    def __init__(self):
        self._conteudo = ""
        
    def _extrairConteudo(self,paginaWeb):
        soup = BeautifulSoup(paginaWeb, "html.parser") 
        self._conteudo = [para.get_text() for para in soup.find_all("p")]
        return self._conteudo
        
    def getConteudo(self,paginaWeb)->str:
        return self._extrairConteudo(paginaWeb)
    
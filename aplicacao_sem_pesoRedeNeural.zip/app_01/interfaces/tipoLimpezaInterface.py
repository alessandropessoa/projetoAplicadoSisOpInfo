from abc import ABC, abstractmethod


class TipoLimpezaInterface(ABC):
    
    @abstractmethod
    def setTexto(self,texto:str):
        ...
        
    @abstractmethod
    def getTexto(self):
        ...
        
        
    @abstractmethod
    def executar(self,texto:str)-> str:
        raise NotImplemented
    
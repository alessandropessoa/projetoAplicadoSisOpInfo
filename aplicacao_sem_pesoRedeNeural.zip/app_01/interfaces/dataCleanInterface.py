from abc import ABC, abstractmethod


class Limpeza(ABC):
    @abstractmethod
    def setTipoLimpeza(tpLimp):
        pass
    
    
    @abstractmethod
    def getTipoLimpeza():
        pass
    
        
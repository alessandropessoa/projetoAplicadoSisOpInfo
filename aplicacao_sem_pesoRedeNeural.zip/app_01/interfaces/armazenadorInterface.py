from abc import ABC,abstractmethod

class ArmazenadorInterface(ABC):
    @abstractmethod
    def setIdentificador(self,identificador):
        raise NotImplemented
        self._identificador = identificador
        
    @abstractmethod
    def getIdentificador(self)-> str:
        raise NotImplemented
        return str
    
    @abstractmethod
    def setConteudo(self,conteudo):
        raise NotImplemented
        self._conteudo = conteudo
    
    @abstractmethod    
    def getConteudo()->str:
        raise NotImplemented
        return str
    
    @abstractmethod
    def armazenar(self):
        raise NotImplemented
        